<div class="flex items-center text-sm text-gray-500 ml-4">
    🔎 Podés buscar por <strong> nombre </strong> o <strong> descripción</strong>.
</div>
