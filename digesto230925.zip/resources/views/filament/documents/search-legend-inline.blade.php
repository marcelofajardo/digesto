<div class="filament-tables-header-toolbar flex items-center justify-between">
    <div class="text-sm text-gray-500">
        🔎 Podés buscar por <strong>nombre</strong> o <strong>descripción</strong>.
    </div>

    {{-- Acá Filament ya mete automáticamente el buscador y los filtros --}}
</div>
