<div class="flex items-center text-sm text-gray-500 ml-4">
    🔎 Podés buscar por <strong> nombre </strong> o <strong> descripción</strong>.
</div>
<?php /**PATH /home/ubuntu/sites/digesto230925/resources/views/filament/documents/search-legend.blade.php ENDPATH**/ ?>